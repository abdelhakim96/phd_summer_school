function [xdot]=plant_model(t,x,A,B,u,d)
% Model Predictive Control
% Tutorial session
% Function describing the continous time model of the servo-mechanism
% example
xdot=A*x+B*[u;d];
end

