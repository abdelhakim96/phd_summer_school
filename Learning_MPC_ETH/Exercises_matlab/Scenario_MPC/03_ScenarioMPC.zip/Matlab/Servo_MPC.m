% Learning-Based Model Predictive Control
% Tutorial session on scenario MPC
% Script to set up and simulate a linear-quadratic MPC strategy
% for the linear servo-mechanism example, with state and input inequality constraints
% and to test scenario MPC strategies

clear all
close all
clc

%% System model
% Model parameters

Rmot    =   20;             % Electric resistance (Ohm)
Kt      =   10;             % Motor constant (Nm/A)
Ktheta  =   1280;           % Torsional stiffness of the output shaft (Nm/rad)
tau_g   =   20;             % Gear ratio
J_i     =   0.5;            % Input shaft moment of inertia (kg m^2)
J_o     =   25;             % Output shaft moment of inertia (kg m^2)
beta_i  =   0.1;            % Input shaft friction coefficient (Nm s/rad)
beta_o  =   25;             % Output shaft friction coefficient (Nm s/rad)
Tbar    =   25;             % Maximum torsional moment (Nm)
Vbar    =   220;            % Maximum input voltage (V)
Ts      =   0.25;           % Sampling time (s)                              
Davg    =   24;             % Average torque disturbance (Nm)
Damp    =   2;              % Half-range of torque disturbance variation (Nm)

% System model - continuous time

Act     = [0 0 1 0;
            0 0 0 1;
            -Ktheta/(J_i*tau_g^2) Ktheta/(J_i*tau_g) -(beta_i+Kt^2/Rmot)/J_i 0;
            Ktheta/(J_o*tau_g) -Ktheta/J_o 0 -beta_o/J_o];

Buct    = [0;0;Kt/(J_i*Rmot);0];
Bdct    = [0;0;0;1/J_o];  % Disturbance input matrix (torque acting on output shaft)

Bct     = [Buct Bdct];

Cct     = [0 1 0 0];

Dct     = zeros(1,2);

% Discrete-time model with zoh
Model           =   c2d(ss(Act,Bct,Cct,Dct),Ts);  

% System model matrices (discrete time):
[A,B,C,D]       =   ssdata(Model);                  % Model matrices 
Bu              =   B(:,1);
Du              =   D(:,1);
Bd              =   B(:,2);
Dd              =   D(:,2);

%% MPC design
% Signal dimensions

nx      =   size(A,1);      % number of states
nu      =   size(Bu,2);     % number of inputs
nd      =   size(Bd,2);     % number of inputs
ny      =   size(C,1);      % number of outputs

% Prediction horizon and cost function weighting matrices
N       =   30;
Q       =   1;
R       =   1e-5;

%% Inequality constraints
% Input inequality constraints (i.e. constraints on input voltage in this example)

Cu      =   [eye(nu);-eye(nu)];
du      =   Vbar*ones(2*nu,1);
nqu     =   size(Cu,1);                 % Number of input inequality constraints per stage

% State inequalities (i.e. maximum torsional moment)
Cx     =   [Ktheta/tau_g -Ktheta 0 0;-Ktheta/tau_g +Ktheta 0 0];
dx     =   Tbar*ones(2,1);
nqx    =   size(Cx,1);

%% Reference output and initial state

x0     =   zeros(nx,1);     % initial state of the plant
yref    =   2*ones(ny,1);   % constant reference output

%% Build overall matrices and vectors for QP (note - quadprog solves: min 0.5*x'*H*x + f'*x subject to: A*x <= b, Aeq*x = beq)

[Lambda_y,Gamma_y,Lambda_x,Gamma_x]     =   Traj_matrices(N,A,Bu,C,Du);
[~,E_y,~,E_x]                           =   Traj_matrices(N,A,Bd,C,Dd);
Qbar                                	=   zeros((N+1)*ny);
Rbar                                    =   zeros(N*nu);
Yref                                    =   zeros((N+1)*ny,1);
Cubar                                   =   zeros(N*nqu,N*nu);
dubar                                   =   zeros(N*nqu,1);
Cxbar                                   =   zeros((N+1)*nqx,(N+1)*nx);
dxbar                                   =   zeros((N+1)*nqx,1);

for ind = 1:N+1
    Qbar((ind-1)*ny+1:ind*ny,(ind-1)*ny+1:ind*ny)           =   Q;
    Yref((ind-1)*ny+1:ind*ny,1)                             =   yref;
    Cxbar((ind-1)*nqx+1:ind*nqx,(ind-1)*nx+1:ind*nx)        =   Cx;
    dxbar((ind-1)*nqx+1:ind*nqx,1)                          =   dx;
end

for ind = 1:N
    Rbar((ind-1)*nu+1:ind*nu,(ind-1)*nu+1:ind*nu)           =   R;
    Cubar((ind-1)*nqu+1:ind*nqu,(ind-1)*nu+1:ind*nu)        =   Cu;
    dubar((ind-1)*nqu+1:ind*nqu,1)                          =   du;
end

% Select the number of scenarios disturbance scenarios
epsilon     =   0.3;                            % Close-loop share of violations over time
K           =   max(1,ceil(nu/epsilon-1));      % sample complexity

% Constraints
Aineq   =   [Cubar;zeros(size(Cxbar*Gamma_x,1)*K,size(Cxbar*Gamma_x,2))];
bineq   =   [dubar;zeros(size(dxbar,1)*K,1)];
for ind=1:K
    Aineq(length(dubar)+(ind-1)*size(Cxbar*Gamma_x,1)+1:length(dubar)+ind*size(Cxbar*Gamma_x,1),:)   =   Cxbar*Gamma_x;
end

% Include slack variable (soft constraints)
Aineq   =   [Aineq [zeros(length(dubar),1);-ones(size(Aineq,1)-length(dubar),1)]];

% Cost function
H       =   2*[(Gamma_y'*Qbar*Gamma_y)+Rbar zeros(N*nu,1);zeros(1,N*nu) 1e10];
H       =   0.5*(H+H');     % To ensure matrix is symmetric
%% QP options

options =   optimset('display','none');

%% Simulate with MPC
Nsim                    =   100;                    % duration of simulation (n. of steps)
Xsim                    =   zeros((Nsim+1)*nx,1);   % allocate vector to collect state trajectory of the plant
Ysim                    =   zeros(Nsim*ny,1);       % allocate vector to collect output trajectory of the plant
Usim                    =   zeros(Nsim*nu,1);       % allocate vector to collect input variation trajectory
Dsim                    =   zeros(Nsim*nd,1);       % allocate vector to collect disturbance trajectory
Vsim                    =   zeros(Nsim,1);          % allocate vector to collect slack variable trajectory
Xsim(1:nx,1)            =   x0;                     % set initial state
xt                      =   x0;                     % current state at generic time t
tQP                     =   zeros(Nsim-1,1);        % allocate vector to collect computational time

for ind=2:Nsim+1
%     bineq                               =   [dubar;dxbar-Cxbar*Lambda_x*xt];
    Dsamples    =   Davg+Damp*2*(rand(N,K)-0.5);
    for ind2=1:K
        bineq(length(dubar)+(ind2-1)*size(dxbar,1)+1:length(dubar)+ind2*size(dxbar,1),1)=...
            dxbar-Cxbar*Lambda_x*xt-Cxbar*E_x*Dsamples(:,ind2);
    end
    f                                   =   [xt'*Lambda_y'*Qbar*Gamma_y-Yref'*Qbar*Gamma_y 0];
    tic     % start counting solution time
    QP_sol                              =   quadprog(H,f,Aineq,bineq,[],[],[],[],[],options); % solve QP
    U                                   =   QP_sol(1:end-1,1);
    slack                               =   QP_sol(end,1);
    tQP(ind-1,1)                        =   toc;        % stop counting solution time
    Usim((ind-2)*nu+1:(ind-1)*nu,1)     =   U(1:nu,1);  % select first control move
    Vsim(ind-1,1)                       =   slack;
    dist                                =   Davg+Damp*2*(rand-0.5); % true disturbance acting on the system
    Dsim((ind-2)*nd+1:(ind-1)*nd,1)     =   dist;
    xtraj                               =   ... 
        ode45(@(t,x)plant_model(t,x,Act,Bct,Usim((ind-2)*nu+1:(ind-1)*nu,1),dist),...
        [0 Ts],Xsim((ind-2)*nx+1:(ind-1)*nx,1));        % simulate the plant (variable step solver)
    xtp1                                =   xtraj.y(:,end);
    
    Xsim((ind-1)*nx+1:ind*nx,1)         =   xtp1;       % update plant state
    Ysim((ind-2)*ny+1:(ind-1)*ny,1)     =   ...     
        Cct*Xsim((ind-2)*nx+1:(ind-1)*nx,1)+...
        Dct*[Usim((ind-2)*nu+1:(ind-1)*nu,1);
        Dsim((ind-2)*nd+1:(ind-1)*nd,1)];               % update plant output
    xt                                  =   xtp1;
end
figure(1),subplot(3,1,1),plot(Ts*[0:1:Nsim-1],Xsim(2:nx:Nsim*nx)),grid on, hold on,title('Output position')
xlabel('Time (s)')
subplot(3,1,2),plot(Ts*[0:1:(Nsim-1)]',Usim),grid on, hold on,title('Input voltage')
xlabel('Time (s)')
subplot(3,1,3),plot(Ts*[0:1:Nsim]',Ktheta*(Xsim(1:nx:end)/tau_g-Xsim(2:nx:end)))
grid on, hold on,title('Torsional moment')
plot(Ts*[0:1:Nsim-1]',Dsim), plot(Ts*[0 Nsim-1]',[Tbar Tbar],'k--')
plot(Ts*[0 Nsim-1]',[-Tbar -Tbar],'r--')
legend('Torsional moment','Disturbance','upper limit','lower limit')
xlabel('Time (s)')
figure(2),plot(Ts*[0:1:(Nsim-1)]',tQP),grid on, hold on,title('QP solution time (s)')
figure(3),plot(Ts*[0:1:(Nsim-1)]',Vsim),grid on, hold on,title('Slack variable')

Torsional_moment=Ktheta*(Xsim(1:nx:end)/tau_g-Xsim(2:nx:end));
% Compute average-in-time violations with slack variable
violations  =   abs(Torsional_moment(2:end))-Vsim-Tbar;
violations  =   violations>=0;
figure(10),plot(violations),hold on
sum(violations)/Nsim

% Compute average-in-time violations without slack variable
violations_noslack  =   abs(Torsional_moment(2:end))-Tbar;
violations_noslack  =   violations_noslack>=0;
figure(10),plot(violations_noslack)
sum(violations_noslack)/Nsim


% license('inuse')